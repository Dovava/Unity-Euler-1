﻿using UnityEngine;
using System.Collections.Generic;
using TMPro;
public class Euler1 : MonoBehaviour
{
    public TextMeshProUGUI textMesh;
    List<int> multiples = new List<int>();
    int answer;
    void Start()
    {
        for (int i = 0; i < 1000; i++) {
            if ((i % 5) == 0 || (i % 3) == 0) {
                multiples.Add(i);
            }
        }
        foreach (int m in multiples) {
            answer += m;    
        }
        textMesh.SetText(answer.ToString());
    }
}
